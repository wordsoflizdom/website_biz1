# Editing guide (non-developer)

All words live in `content/`. Layout lives in `js/render.js` and `css/` (leave these alone).

| To change | Open |
|---|---|
| Email, phone, nav labels/links, social links, footer line | `content/site.js` |
| Homepage headline, copy, buttons; hide/reorder sections | `content/home.js` (`sections` list at top: move lines, or set `show: false`) |
| Artists page text and situations | `content/artists.js` |
| Institutions page text and situations | `content/institutions.js` |
| Bio, experience, education, portrait | `content/about.js` |
| Selected projects | `content/projects.js` |
| Form labels, form delivery | `content/contact.js` |
| Colours, fonts, sizes | `css/tokens.css` |

**Edit text:** change only what is between the quotation marks. Keep the quotes, commas and brackets. Wrap a word in *asterisks* for an accent italic.

**Add, remove or reorder a situation or service:** in `artists.js` or `institutions.js`, each `{ title: "...", text: "..." }` line is one item. Copy one, delete one, or move it.

**Add a project:** copy a `{ ... }` block in `content/projects.js`, paste it at the top of the list (keep the comma after `}`), fill in the fields. Only `title` is required; empty fields are hidden. Add `placeholder: true` to show a "Draft" tag.

**Replace images:** put the file in `images/`, then set `image: "images/yourfile.jpg"` in the project. Any aspect ratio works; it is cropped to 4:5. Portrait: `portrait` in `content/about.js`.

**Contact details:** change `email` and `phone` once in `content/site.js`.

**Preview:** double-click `index.html`, then refresh the browser after each save.

**Publish:** drag the whole folder onto Netlify Drop (app.netlify.com/drop), or connect a GitHub repository to Cloudflare Pages or Netlify (free tiers). Then set `siteUrl` in `content/site.js`.

**Safe for you:** `content/`, `images/`, `css/tokens.css`. **Ask a developer:** `js/render.js`, `css/style.css`, new pages, a live form backend, a visual CMS.

**If the site goes blank:** a comma, quote or bracket was deleted. Undo your last change.
